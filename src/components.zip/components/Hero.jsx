import { motion } from 'motion/react'

function Hero() {
  const fadeUp = {
    hidden: { opacity: 0, y: 24 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  }

  const stagger = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.12,
      },
    },
  }

  return (
    <section
      id="home"
      className="relative min-h-screen overflow-hidden bg-black px-5 sm:px-6 md:px-10 lg:px-12"
    >
      {/* ================= AMBIENT GLOW ================= */}
      <motion.div
        className="pointer-events-none absolute left-[45%] top-[35%] h-[350px] w-[350px] -translate-x-1/2 rounded-full bg-blue-500/[0.06] blur-[100px] sm:h-[450px] sm:w-[450px] sm:blur-[120px] md:h-[500px] md:w-[500px] md:blur-[140px]"
        animate={{
          scale: [1, 1.08, 1],
          opacity: [0.6, 1, 0.6],
        }}
        transition={{
          duration: 7,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      <motion.div
        className="pointer-events-none absolute bottom-0 right-[5%] h-[300px] w-[300px] rounded-full bg-purple-500/[0.04] blur-[100px] sm:h-[350px] sm:w-[350px] md:right-[10%] md:h-[400px] md:w-[400px] md:blur-[130px]"
        animate={{
          scale: [1, 1.12, 1],
          opacity: [0.5, 0.8, 0.5],
        }}
        transition={{
          duration: 9,
          repeat: Infinity,
          ease: 'easeInOut',
          delay: 1,
        }}
      />

      {/* ================= DECORATIVE GRID ================= */}
      <motion.div
        className="pointer-events-none absolute inset-0 opacity-[0.035]"
        animate={{ opacity: [0.02, 0.04, 0.02] }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      >
        <div
          className="h-full w-full"
          style={{
            backgroundImage:
              'linear-gradient(rgba(255,255,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,1) 1px, transparent 1px)',
            backgroundSize: '80px 80px',
          }}
        />
      </motion.div>

      <div className="relative mx-auto min-h-screen max-w-7xl">

        {/* ================= CONTENT ================= */}
        <motion.div
          className="
            relative z-20 w-full
            pt-28
            pb-[330px]

            sm:pt-32
            sm:pb-[350px]

            md:pb-32

            lg:w-[62%]
            lg:pt-20
            lg:pb-32
          "
          variants={stagger}
          initial="hidden"
          animate="visible"
        >
          {/* Label */}
          <motion.div
            variants={fadeUp}
            className="mb-6 flex items-center gap-3 sm:mb-8 sm:gap-4"
          >
            <span className="h-px w-7 shrink-0 bg-white/30 sm:w-10" />

            <p className="text-[10px] uppercase leading-relaxed tracking-[0.2em] text-gray-400 sm:text-xs sm:tracking-[0.35em]">
              Information Systems Student
            </p>
          </motion.div>

          {/* Name */}
          <motion.h1
            variants={fadeUp}
            className="
              text-[18vw]
              font-bold
              leading-[0.76]
              tracking-[-0.08em]
              text-white
              sm:text-[7rem]
              md:text-[8rem]
              lg:text-[10rem]
            "
          >
            Afdal
            <br />

            <span className="text-gray-500">
              Indra<span className="text-white">.</span>
            </span>
          </motion.h1>

          {/* Description */}
          <motion.div
            variants={fadeUp}
            className="mt-7 max-w-[340px] sm:mt-10 sm:max-w-xl md:mt-12"
          >
            <p className="text-[13px] leading-relaxed text-gray-400 sm:text-base md:text-lg">
              I explore the intersection of{' '}
              <span className="text-gray-200">technology</span>,{' '}
              <span className="text-gray-200">creativity</span>,{' '}
              <span className="text-gray-200">organization</span>, and{' '}
              <span className="text-gray-200">
                digital experiences
              </span>
              .
            </p>
          </motion.div>

          {/* CTA */}
          <motion.div
            variants={fadeUp}
            className="mt-7 flex flex-wrap gap-3 sm:mt-9 sm:gap-4"
          >

            <motion.a
              href="#about"
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.97 }}
              className="
                rounded-full
                border
                border-white/15
                px-5
                py-3
                text-xs
                text-white
                transition-all
                duration-300
                hover:border-white/40
                hover:bg-white/5
                sm:px-7
                sm:py-3.5
                sm:text-sm
              "
            >
              About me
            </motion.a>
          </motion.div>
        </motion.div>

        {/* ================= PHOTO ================= */}
        <motion.div
          className="
            pointer-events-none absolute
            bottom-0
            left-1/2
            z-10
            h-[43vh]
            w-[105%]
            -translate-x-1/2
            sm:h-[50vh]
            sm:w-[90%]
            md:left-auto
            md:right-[-5%]
            md:h-[70vh]
            md:w-[60%]
            md:translate-x-0
            lg:right-[-2%]
            lg:h-[90vh]
            lg:w-[48%]
          "
          initial={{ opacity: 0, y: 50, scale: 0.96 }}
          animate={{
            opacity: 1,
            y: [25, 0, 25],
            scale: 1,
          }}
          transition={{
            opacity: {
              duration: 1,
              delay: 0.45,
              ease: 'easeOut',
            },
            scale: {
              duration: 1,
              delay: 0.45,
              ease: 'easeOut',
            },
            y: {
              duration: 6,
              repeat: Infinity,
              ease: 'easeInOut',
              delay: 1.4,
            },
          }}
        >
          {/* Photo Glow */}
          <motion.div
            className="
              absolute
              bottom-[8%]
              left-1/2
              h-[50%]
              w-[65%]
              -translate-x-1/2
              rounded-full
              bg-blue-400/[0.07]
              blur-[60px]
              sm:blur-[80px]
              md:blur-[100px]
            "
            animate={{
              scale: [1, 1.08, 1],
              opacity: [0.5, 0.8, 0.5],
            }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />

          {/* Orbit 1 */}
          <motion.div
            className="
              absolute
              left-1/2
              top-[32%]
              hidden
              h-[220px]
              w-[400px]
              -translate-x-1/2
              rotate-[-18deg]
              rounded-[50%]
              border
              border-white/[0.07]
              md:block
              md:h-[250px]
              md:w-[450px]
              lg:h-[280px]
              lg:w-[500px]
            "
            animate={{
              rotate: [-18, -14, -18],
              scale: [1, 1.03, 1],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />

          {/* Orbit 2 */}
          <motion.div
            className="
              absolute
              left-1/2
              top-[32%]
              hidden
              h-[220px]
              w-[400px]
              -translate-x-1/2
              rotate-[18deg]
              rounded-[50%]
              border
              border-white/[0.035]
              md:block
              md:h-[250px]
              md:w-[450px]
              lg:h-[280px]
              lg:w-[500px]
            "
            animate={{
              rotate: [18, 22, 18],
              scale: [1, 1.03, 1],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: 'easeInOut',
              delay: 0.5,
            }}
          />

          {/* Decorative Dot */}
          <motion.div
            className="
              absolute
              right-[15%]
              top-[30%]
              hidden
              h-2
              w-2
              rounded-full
              bg-white
              shadow-[0_0_20px_rgba(255,255,255,0.7)]
              md:block
            "
            animate={{
              opacity: [0.3, 1, 0.3],
              scale: [0.8, 1.2, 0.8],
            }}
            transition={{
              duration: 2.5,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />

          {/* Person */}
          <img
            src="/afdal.png"
            alt="Afdal Indra Maulana"
            className="
              absolute
              bottom-0
              left-1/2
              h-full
              w-auto
              -translate-x-1/2
              object-contain
              object-bottom
              drop-shadow-[0_15px_45px_rgba(0,0,0,0.8)]
            "
          />
        </motion.div>

        {/* ================= BOTTOM INFO ================= */}
        <div className="absolute bottom-6 left-0 right-0 z-30 sm:bottom-8">

          {/* Social */}
          <motion.div
            className="hidden md:block"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 1 }}
          >
            <p className="mb-3 text-[10px] uppercase tracking-[0.3em] text-gray-600">
              Find me on
            </p>

            <div className="flex gap-5 text-xs text-gray-500">
              <a
                href="https://www.linkedin.com/in/afdal-indra-maulana-7103b5359?utm_source=share_via&utm_content=profile&utm_medium=member_ios"
                target="_blank"
                rel="noopener noreferrer"
                className="transition hover:text-white"
              >
                LinkedIn
              </a>

              <a
                href="https://github.com/afdalim"
                target="_blank"
                rel="noopener noreferrer"
                className="transition hover:text-white"
              >
                GitHub
              </a>

              <a
                href="https://www.instagram.com/afdalim_18"
                target="_blank"
                rel="noopener noreferrer"
                className="transition hover:text-white"
              >
                Instagram
              </a>
            </div>
          </motion.div>

          {/* Location */}
          <motion.div
            className="hidden text-right md:block"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 1.1 }}
          >
            <p className="mb-3 text-[10px] uppercase tracking-[0.3em] text-gray-600">
              Based in
            </p>

            <p className="text-xs text-gray-500">
              Purwokerto, Indonesia
            </p>
          </motion.div>

          {/* Scroll */}
          <motion.div
            className="pointer-events-none absolute bottom-0 left-1/2 hidden -translate-x-1/2 flex-col items-center md:flex"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.4 }}
          >
            <span className="mb-4 text-[9px] uppercase tracking-[0.45em] text-gray-500">
              Scroll
            </span>

            <div className="relative h-14 w-px overflow-hidden bg-white/10">
              <motion.div
                className="absolute left-0 top-0 h-5 w-px bg-white/60"
                animate={{ y: [-20, 60] }}
                transition={{
                  duration: 1.8,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }}
              />
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  )
}

export default Hero