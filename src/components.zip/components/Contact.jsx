import Reveal from './Reveal'

function Contact() {
  return (
    <section
      id="contact"
      className="border-t border-white/10 px-6 py-32 md:px-12"
    >
      <div className="mx-auto max-w-7xl">

        {/* Header */}
        <Reveal>
          <div className="mb-20">
            <p className="mb-6 text-sm uppercase tracking-[0.3em] text-gray-500">
              06 — Contact
            </p>

            <h2 className="text-5xl font-semibold leading-[0.95] tracking-tight md:text-7xl lg:text-8xl">
              Let's make
              <br />
              <span className="text-gray-500">
                something together.
              </span>
            </h2>
          </div>
        </Reveal>

        {/* Contact Content */}
        <div className="grid gap-16 lg:grid-cols-2">

          {/* Intro */}
          <Reveal direction="left">
            <div>

              <p className="max-w-lg text-lg leading-relaxed text-gray-500">
                Whether it's a project, collaboration, organization,
                internship opportunity, or simply a conversation about
                technology and creativity, feel free to reach out.
              </p>

              <a
                href="mailto:afdalindram2006@gmail.com"
                className="mt-8 inline-block border-b border-white/20 pb-2 text-xl transition-colors duration-300 hover:border-white md:text-2xl"
              >
                afdalindram2006@gmail.com
              </a>

            </div>
          </Reveal>

          {/* Links */}
          <Reveal direction="right">
            <div>

              <a
                href="https://www.linkedin.com/in/afdal-indra-maulana-7103b5359?utm_source=share_via&utm_content=profile&utm_medium=member_ios"
                className="group flex items-center justify-between border-t border-white/10 py-6 transition-all duration-300 hover:px-4"
              >
                <span className="text-xl md:text-2xl">
                  LinkedIn
                </span>

                <span className="text-xl text-gray-500 transition-all duration-300 group-hover:translate-x-2 group-hover:text-white">
                  ↗
                </span>
              </a>

              <a
                href="https://github.com/afdalim"
                className="group flex items-center justify-between border-t border-white/10 py-6 transition-all duration-300 hover:px-4"
              >
                <span className="text-xl md:text-2xl">
                  GitHub
                </span>

                <span className="text-xl text-gray-500 transition-all duration-300 group-hover:translate-x-2 group-hover:text-white">
                  ↗
                </span>
              </a>

              <a
                href="https://www.instagram.com/afdalim_18?igsi=MThkZjd1enUxZHc0YQ%3D%3D&utm_source=qr"
                className="group flex items-center justify-between border-t border-white/10 py-6 transition-all duration-300 hover:px-4"
              >
                <span className="text-xl md:text-2xl">
                  Instagram
                </span>

                <span className="text-xl text-gray-500 transition-all duration-300 group-hover:translate-x-2 group-hover:text-white">
                  ↗
                </span>
              </a>

              <a
                href="https://www.tiktok.com/@af18jul06?_r=1&_t=ZS-99CGhRn6yJz"
                className="group flex items-center justify-between border-b border-t border-white/10 py-6 transition-all duration-300 hover:px-4"
              >
                <span className="text-xl md:text-2xl">
                  TikTok
                </span>

                <span className="text-xl text-gray-500 transition-all duration-300 group-hover:translate-x-2 group-hover:text-white">
                  ↗
                </span>
              </a>

            </div>
          </Reveal>

        </div>

        {/* Bottom */}
        <Reveal delay={0.3}>
          <div className="mt-24 flex flex-col justify-between gap-4 border-t border-white/10 pt-6 text-xs uppercase tracking-[0.2em] text-gray-600 md:flex-row">
            <span>
              Available for opportunities
            </span>

            <span>
              Purwokerto, Indonesia
            </span>
          </div>
        </Reveal>

      </div>
    </section>
  )
}

export default Contact